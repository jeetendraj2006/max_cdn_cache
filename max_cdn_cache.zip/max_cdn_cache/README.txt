$Id

WHAT IS THIS MODULE FOR?

You may need it when you want to:

- clear cache for MaxCND from API


USAGE INSTRUCTIONS

Create API For MaxCDN
1. Create API on MaxCDN Account
    a. Goto https://cp.maxcdn.com/account/api
    b. Click "Create Application"
    c. Enter Name, Description, Application URL.
    d. Select Permission.
    d. Save.

1. Install the module.

2. Configure the module

	a. Goto Configuration->Development-> Performance.
	b. Select "MaxCDN Cache Settings" tab.
	c. Enter Alias, Consumer Key, Consumer Secret (get this detail fron MaxCDN api dashboard https://cp.maxcdn.com/account/api ).
	d. Click on save Configuration.

