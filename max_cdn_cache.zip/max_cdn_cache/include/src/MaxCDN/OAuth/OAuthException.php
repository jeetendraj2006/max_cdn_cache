<?php
/**
 * Exception class for OAuth failures.
 */
namespace MaxCDN\OAuth;

class OAuthException extends Exception {
    // pass
}

